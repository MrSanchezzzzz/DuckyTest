
class User {
  final String displayName;
  final String email;

  User({
    required this.displayName,
    required this.email,
  });
}
