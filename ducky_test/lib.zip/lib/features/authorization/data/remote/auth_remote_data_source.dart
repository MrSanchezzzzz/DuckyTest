
import 'package:atlassian_apis/jira_platform.dart';
class AuthRemoteDataSource {
  final String host;

  AuthRemoteDataSource(this.host);

  Future<User> authenticate(String email, String token) async {
    final client = ApiClient.basicAuthentication(
      Uri.https(host, ''),
      user: email,
      apiToken: token,
    );

    final jira = JiraPlatformApi(client);

    try {
      final user = await jira.myself.getCurrentUser();
      return User(
        displayName: user.displayName ?? '',
        emailAddress: user.emailAddress ?? '',
      );
    } finally {
      client.close();
    }
  }
}
