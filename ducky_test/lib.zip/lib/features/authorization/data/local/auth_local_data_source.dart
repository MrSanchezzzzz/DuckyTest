
import 'package:atlassian_apis/jira_platform.dart';
class AuthLocalDataSource {
  Future<User> authenticate(String email, String? token) async {
      return User(
        displayName: 'Test User',
        emailAddress: 'test@me.com',
      );
  }
}
