// lib/features/authorization/presentation/screens/authorization_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/data/platform_api_provider.dart';
import '../../../home/presentation/screens/home_screen.dart';

class AuthorizationScreen extends ConsumerWidget {
  const AuthorizationScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextEditingController emailController = TextEditingController();
    final TextEditingController tokenController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Authorization'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: tokenController,
              decoration: const InputDecoration(labelText: 'Token'),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final email = emailController.text;
                final token = tokenController.text;
                const host = 'https://richbirdskek.atlassian.net/'; // You might want to make it configurable

                // Configure the ApiClient
                final config = ApiClientConfig(
                  host: host,
                  user: email,
                  apiToken: token,
                );

                // Use the provider to access the JiraPlatformApi
                final jiraApi = ref.read(platformApiProvider(config));

                try {
                  final user = await jiraApi.myself.getCurrentUser();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Authenticated as: ${user.displayName}')),
                  );
                  // Navigate to the HomeScreen on success (passing username and email)
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HomeScreen(
                        username: user.displayName ?? 'Unknown User',
                        email: user.emailAddress ?? 'No Email',
                      ),
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Authentication failed')),
                  );
                }
              },
              child: const Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}
