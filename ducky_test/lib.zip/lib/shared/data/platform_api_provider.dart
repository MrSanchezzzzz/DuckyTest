import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:atlassian_apis/jira_platform.dart';

final platformApiProvider = Provider.family<JiraPlatformApi, ApiClientConfig>((ref, config) {
  final client = ApiClient.basicAuthentication(
    Uri.https(config.host, ''),
    user: config.user,
    apiToken: config.apiToken,
  );
  return JiraPlatformApi(client);
});

// Configuration class for creating an ApiClientConfig
class ApiClientConfig {
  final String host;
  final String user;
  final String apiToken;

  ApiClientConfig({
    required this.host,
    required this.user,
    required this.apiToken,
  });
}
